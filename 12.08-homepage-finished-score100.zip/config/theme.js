module.exports = {
  colors: {
    header: { 
      menu: {
        bg: '#2A2A2A',
        active: '#FFF',
        link: '#828181'
      }
    }  
  }
}
