import React from 'react'

import Layout from '../components/layout'

const Services = () => <h1>Hello from Services</h1>

export default Services
